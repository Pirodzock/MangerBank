package com.example.bankmanager;

import android.os.Build;

import androidx.annotation.RequiresApi;

import java.util.ArrayList;

public class BankAccount {

    private int accountNumber;
    private String ownerName;
    private double balance;
    private ArrayList<Transaction> transactions;

    public BankAccount(int accountNumber, String ownerName, double balance) {
        this.accountNumber = accountNumber;
        this.ownerName = ownerName;
        this.balance = balance;
        this.transactions = new ArrayList<>();
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void deposit(double amount) throws InvalidAmountException {
        if (amount <= 0) {
            throw new InvalidAmountException("סכום ההפקדה חייב להיות חיובי");
        }

        balance += amount;
        transactions.add(new Transaction("Deposit", amount));
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void withdraw(double amount)
            throws InvalidAmountException, InsufficientFundsException {

        if (amount <= 0) {
            throw new InvalidAmountException("סכום המשיכה חייב להיות חיובי");
        }

        if (amount > balance) {
            throw new InsufficientFundsException("אין מספיק כסף בחשבון");
        }

        balance -= amount;
        transactions.add(new Transaction("Withdraw", amount));
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void transfer(BankAccount target, double amount)
            throws InvalidAmountException, InsufficientFundsException {

        withdraw(amount);
        target.deposit(amount);
    }

    public double getBalance() {
        return balance;
    }

    public int getAccountNumber() {
        return accountNumber;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public ArrayList<Transaction> getTransactions() {
        return transactions;
    }
}