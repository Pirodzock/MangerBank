package com.example.bankmanager;

import java.util.ArrayList;

public class BankManager {

    private ArrayList<BankAccount> accounts;

    public BankManager() {
        accounts = new ArrayList<>();
    }

    public void addAccount(BankAccount account) {
        accounts.add(account);
    }

    public BankAccount findAccount(int accountNumber) {
        for (BankAccount account : accounts) {
            if (account.getAccountNumber() == accountNumber) {
                return account;
            }
        }

        return null;
    }

    public void removeAccount(int accountNumber) {
        BankAccount account = findAccount(accountNumber);

        if (account != null) {
            accounts.remove(account);
        }
    }

    public ArrayList<BankAccount> getAccounts() {
        return accounts;
    }
}