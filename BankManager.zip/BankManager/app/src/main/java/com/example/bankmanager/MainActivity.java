package com.example.bankmanager;

import android.annotation.SuppressLint;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText editTextAmount;
    private Button buttonWithdraw;
    private BankAccount account;

    private Button buttonDeposit;

    @RequiresApi(api = Build.VERSION_CODES.O)
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextAmount = findViewById(R.id.editTextAmount);
        buttonWithdraw = findViewById(R.id.buttonWithdraw);
        buttonDeposit = findViewById(R.id.buttonDeposit);

        account = new BankAccount(1, "Harel", 1000git);

        buttonWithdraw.setOnClickListener(v -> {

            try {
                double amount = Double.parseDouble(
                        editTextAmount.getText().toString()
                );

                account.withdraw(amount);

                Toast.makeText(this,
                        "המשיכה בוצעה בהצלחה",
                        Toast.LENGTH_SHORT).show();

            } catch (NumberFormatException e) {

                Toast.makeText(this,
                        "יש להזין מספר תקין",
                        Toast.LENGTH_SHORT).show();

            } catch (InsufficientFundsException e) {

                Toast.makeText(this,
                        e.getMessage(),
                        Toast.LENGTH_SHORT).show();

            } catch (InvalidAmountException e) {

                Toast.makeText(this,
                        e.getMessage(),
                        Toast.LENGTH_SHORT).show();

            } finally {

                editTextAmount.setText("");
            }
        });

        buttonDeposit.setOnClickListener(v -> {
            try {
                double amount = Double.parseDouble(
                        editTextAmount.getText().toString()
                );

                account.deposit(amount);

                Toast.makeText(this,
                        "Deposit successful",
                        Toast.LENGTH_SHORT).show();

            } catch (NumberFormatException e) {
                Toast.makeText(this,
                        "Invalid number",
                        Toast.LENGTH_SHORT).show();

            } catch (InvalidAmountException e) {
                Toast.makeText(this,
                        e.getMessage(),
                        Toast.LENGTH_SHORT).show();

            } finally {
                editTextAmount.setText("");
            }
        });
    }
}